package application;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

public class SampleController {
	Label expression;
	
	public void onMouseClick(MouseEvent mouseEvent) {
		Button button= (Button) mouseEvent.getSource();
		String number= button.getText();
	}
	
}
